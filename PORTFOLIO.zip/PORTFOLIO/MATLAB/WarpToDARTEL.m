%-----------------------------------------------------------------------
% Job saved on 31-Dec-2019 15:18:31 by cfg_util (rev $Rev: 7345 $)
% spm SPM - SPM12 (7487)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.tools.dartel.crt_warped.flowfields = {'Z:\Data_Processed\MRI_dicomsort\sorted\1408\CovAnalysis\DARTEL\u_rc1reg_MP2Rage_cleaned_1408_DARTEL.nii'};
matlabbatch{1}.spm.tools.dartel.crt_warped.images = {{'Z:\Data_Processed\MRI_dicomsort\sorted\1408\CovAnalysis\DARTEL\rc1reg_MP2Rage_cleaned_1408.nii'}};
matlabbatch{1}.spm.tools.dartel.crt_warped.jactransf = 0;
matlabbatch{1}.spm.tools.dartel.crt_warped.K = 6;
matlabbatch{1}.spm.tools.dartel.crt_warped.interp = 1;
