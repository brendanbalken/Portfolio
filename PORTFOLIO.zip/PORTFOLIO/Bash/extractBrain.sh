cd /mnt/z/Data_Processed/MRI_dicomsort/sorted/6875/mri
bet2 MP2Rage_cleaned_6875.nii MP2Rage_cleaned_brain_6875.nii -c 92 99 157
gunzip -f MP2Rage_cleaned_brain_6875.nii.gz
